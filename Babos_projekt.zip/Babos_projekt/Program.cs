﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

class Konyv
{
    public string Cim { get; set; }
    public string Iro { get; set; }
    public string Zsaner { get; set; }
    public int Ar { get; set; }
}

class Program
{
    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;

        string fajlUtvonal = FajlKeresese("konyvek.txt");
        if (fajlUtvonal == null)
        {
            Console.WriteLine("Hiba: A 'konyvek.txt' fajl nem talalhato a program mellett!");
            Console.WriteLine("Nyomj meg egy billentyut a kilepeshez...");
            Console.ReadKey();
            return;
        }

        List<Konyv> konyvek = new List<Konyv>();
        string[] sorok = File.ReadAllLines(fajlUtvonal, Encoding.UTF8);

        foreach (string sor in sorok)
        {
            if (string.IsNullOrWhiteSpace(sor))
                continue;

            string[] reszek = sor.Split(';');
            if (reszek.Length < 4)
                continue;

            int ar;
            if (!int.TryParse(reszek[3].Trim(), out ar))
                continue;

            Konyv ujKonyv = new Konyv();
            ujKonyv.Cim = reszek[0].Trim();
            ujKonyv.Iro = reszek[1].Trim();
            ujKonyv.Zsaner = reszek[2].Trim();
            ujKonyv.Ar = ar;
            konyvek.Add(ujKonyv);
        }

        if (konyvek.Count == 0)
        {
            Console.WriteLine("A 'konyvek.txt' fajl nem tartalmaz ervenyes konyvadatokat!");
            Console.ReadKey();
            return;
        }

        Console.WriteLine("A könyvesbolt kínálata\n");
        foreach (Konyv k in konyvek)
        {
            Console.WriteLine("- " + k.Cim + " | Iro: " + k.Iro + " | Zsaner: " + k.Zsaner + " | Ar: " + k.Ar + " Ft");
        }

        Konyv legdragabb = konyvek[0];
        foreach (Konyv k in konyvek)
        {
            if (k.Ar > legdragabb.Ar)
                legdragabb = k;
        }
        Console.WriteLine("\n1. Legdrágább könyv: " + legdragabb.Cim + " (" + legdragabb.Ar + " Ft)");

        Konyv legolcsobb = konyvek[0];
        foreach (Konyv k in konyvek)
        {
            if (k.Ar < legolcsobb.Ar)
                legolcsobb = k;
        }
        Console.WriteLine("2. Legolcsóbb könyv: " + legolcsobb.Cim + " (" + legolcsobb.Ar + " Ft)");

        int osszar = 0;
        foreach (Konyv k in konyvek)
        {
            osszar += k.Ar;
        }
        double atlagar = (double)osszar / konyvek.Count;
        Console.WriteLine("3. Könyvek átlagára: " + atlagar.ToString("F0") + " Ft");

        string keresettZsaner = "Regény";
        Console.WriteLine("4. '" + keresettZsaner + "' zsánerű könyvek:");
        foreach (Konyv k in konyvek)
        {
            if (string.Equals(k.Zsaner, keresettZsaner, StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine("   - " + k.Cim + " (" + k.Iro + ")");
            }
        }

        Console.WriteLine("\nNyomj meg egy billentyűt a kilépéshez...");
        Console.ReadKey();
    }

    static string FajlKeresese(string fajlNev)
    {
        if (File.Exists(fajlNev))
            return fajlNev;

        string baseDirUt = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, fajlNev);
        if (File.Exists(baseDirUt))
            return baseDirUt;

        return null;
    }
}